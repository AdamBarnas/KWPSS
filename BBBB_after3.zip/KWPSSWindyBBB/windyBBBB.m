toUp1 = 0;
toUp2 = 0;
toDown2 = 0;
toDown3 = 0;

fixdt(0,32,5)


a = uint32(30)