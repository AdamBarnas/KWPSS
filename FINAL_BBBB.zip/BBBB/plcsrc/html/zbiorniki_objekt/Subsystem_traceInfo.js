function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <S1>/Constant */
	this.urlHashMap["zbiorniki_objekt:7"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:7";
	/* <S1>/Constant1 */
	this.urlHashMap["zbiorniki_objekt:8"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:8";
	/* <S1>/Constant2 */
	this.urlHashMap["zbiorniki_objekt:9"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:9";
	/* <S1>/Constant3 */
	this.urlHashMap["zbiorniki_objekt:10"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:10";
	/* <S1>/Constant4 */
	this.urlHashMap["zbiorniki_objekt:11"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:11";
	/* <S1>/Constant5 */
	this.urlHashMap["zbiorniki_objekt:37"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:37";
	/* <S1>/Constant6 */
	this.urlHashMap["zbiorniki_objekt:42"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:42";
	/* <S1>/Data Type Conversion */
	this.urlHashMap["zbiorniki_objekt:43"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:43";
	/* <S1>/Data Type Conversion1 */
	this.urlHashMap["zbiorniki_objekt:44"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:44";
	/* <S1>/Data Type Conversion2 */
	this.urlHashMap["zbiorniki_objekt:45"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:45";
	/* <S1>/Data Type Conversion3 */
	this.urlHashMap["zbiorniki_objekt:46"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:46";
	/* <S1>/Data Type Conversion4 */
	this.urlHashMap["zbiorniki_objekt:47"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:47";
	/* <S1>/Discrete-Time
Integrator */
	this.urlHashMap["zbiorniki_objekt:32"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:32";
	/* <S1>/Discrete-Time
Integrator1 */
	this.urlHashMap["zbiorniki_objekt:33"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:33";
	/* <S1>/Divide */
	this.urlHashMap["zbiorniki_objekt:5"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:5";
	/* <S1>/Divide1 */
	this.urlHashMap["zbiorniki_objekt:18"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:18";
	/* <S1>/Divide2 */
	this.urlHashMap["zbiorniki_objekt:34"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:34";
	/* <S1>/Divide3 */
	this.urlHashMap["zbiorniki_objekt:35"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:35";
	/* <S1>/Product */
	this.urlHashMap["zbiorniki_objekt:13"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:13";
	/* <S1>/Product1 */
	this.urlHashMap["zbiorniki_objekt:17"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:17";
	/* <S1>/Product2 */
	this.urlHashMap["zbiorniki_objekt:22"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:22";
	/* <S1>/Product3 */
	this.urlHashMap["zbiorniki_objekt:40"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:40";
	/* <S1>/Product4 */
	this.urlHashMap["zbiorniki_objekt:41"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:41";
	/* <S1>/Sqrt */
	this.urlHashMap["zbiorniki_objekt:6"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:6";
	/* <S1>/Sqrt1 */
	this.urlHashMap["zbiorniki_objekt:16"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:16";
	/* <S1>/Sum */
	this.urlHashMap["zbiorniki_objekt:3"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:3";
	/* <S1>/Sum2 */
	this.urlHashMap["zbiorniki_objekt:12"] = "msg=rtwMsg_notTraceable&block=zbiorniki_objekt:12";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "zbiorniki_objekt"};
	this.sidHashMap["zbiorniki_objekt"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<S1>/V1"] = {sid: "zbiorniki_objekt:27"};
	this.sidHashMap["zbiorniki_objekt:27"] = {rtwname: "<S1>/V1"};
	this.rtwnameHashMap["<S1>/P"] = {sid: "zbiorniki_objekt:28"};
	this.sidHashMap["zbiorniki_objekt:28"] = {rtwname: "<S1>/P"};
	this.rtwnameHashMap["<S1>/V2"] = {sid: "zbiorniki_objekt:29"};
	this.sidHashMap["zbiorniki_objekt:29"] = {rtwname: "<S1>/V2"};
	this.rtwnameHashMap["<S1>/Constant"] = {sid: "zbiorniki_objekt:7"};
	this.sidHashMap["zbiorniki_objekt:7"] = {rtwname: "<S1>/Constant"};
	this.rtwnameHashMap["<S1>/Constant1"] = {sid: "zbiorniki_objekt:8"};
	this.sidHashMap["zbiorniki_objekt:8"] = {rtwname: "<S1>/Constant1"};
	this.rtwnameHashMap["<S1>/Constant2"] = {sid: "zbiorniki_objekt:9"};
	this.sidHashMap["zbiorniki_objekt:9"] = {rtwname: "<S1>/Constant2"};
	this.rtwnameHashMap["<S1>/Constant3"] = {sid: "zbiorniki_objekt:10"};
	this.sidHashMap["zbiorniki_objekt:10"] = {rtwname: "<S1>/Constant3"};
	this.rtwnameHashMap["<S1>/Constant4"] = {sid: "zbiorniki_objekt:11"};
	this.sidHashMap["zbiorniki_objekt:11"] = {rtwname: "<S1>/Constant4"};
	this.rtwnameHashMap["<S1>/Constant5"] = {sid: "zbiorniki_objekt:37"};
	this.sidHashMap["zbiorniki_objekt:37"] = {rtwname: "<S1>/Constant5"};
	this.rtwnameHashMap["<S1>/Constant6"] = {sid: "zbiorniki_objekt:42"};
	this.sidHashMap["zbiorniki_objekt:42"] = {rtwname: "<S1>/Constant6"};
	this.rtwnameHashMap["<S1>/Data Type Conversion"] = {sid: "zbiorniki_objekt:43"};
	this.sidHashMap["zbiorniki_objekt:43"] = {rtwname: "<S1>/Data Type Conversion"};
	this.rtwnameHashMap["<S1>/Data Type Conversion1"] = {sid: "zbiorniki_objekt:44"};
	this.sidHashMap["zbiorniki_objekt:44"] = {rtwname: "<S1>/Data Type Conversion1"};
	this.rtwnameHashMap["<S1>/Data Type Conversion2"] = {sid: "zbiorniki_objekt:45"};
	this.sidHashMap["zbiorniki_objekt:45"] = {rtwname: "<S1>/Data Type Conversion2"};
	this.rtwnameHashMap["<S1>/Data Type Conversion3"] = {sid: "zbiorniki_objekt:46"};
	this.sidHashMap["zbiorniki_objekt:46"] = {rtwname: "<S1>/Data Type Conversion3"};
	this.rtwnameHashMap["<S1>/Data Type Conversion4"] = {sid: "zbiorniki_objekt:47"};
	this.sidHashMap["zbiorniki_objekt:47"] = {rtwname: "<S1>/Data Type Conversion4"};
	this.rtwnameHashMap["<S1>/Discrete-Time Integrator"] = {sid: "zbiorniki_objekt:32"};
	this.sidHashMap["zbiorniki_objekt:32"] = {rtwname: "<S1>/Discrete-Time Integrator"};
	this.rtwnameHashMap["<S1>/Discrete-Time Integrator1"] = {sid: "zbiorniki_objekt:33"};
	this.sidHashMap["zbiorniki_objekt:33"] = {rtwname: "<S1>/Discrete-Time Integrator1"};
	this.rtwnameHashMap["<S1>/Divide"] = {sid: "zbiorniki_objekt:5"};
	this.sidHashMap["zbiorniki_objekt:5"] = {rtwname: "<S1>/Divide"};
	this.rtwnameHashMap["<S1>/Divide1"] = {sid: "zbiorniki_objekt:18"};
	this.sidHashMap["zbiorniki_objekt:18"] = {rtwname: "<S1>/Divide1"};
	this.rtwnameHashMap["<S1>/Divide2"] = {sid: "zbiorniki_objekt:34"};
	this.sidHashMap["zbiorniki_objekt:34"] = {rtwname: "<S1>/Divide2"};
	this.rtwnameHashMap["<S1>/Divide3"] = {sid: "zbiorniki_objekt:35"};
	this.sidHashMap["zbiorniki_objekt:35"] = {rtwname: "<S1>/Divide3"};
	this.rtwnameHashMap["<S1>/Product"] = {sid: "zbiorniki_objekt:13"};
	this.sidHashMap["zbiorniki_objekt:13"] = {rtwname: "<S1>/Product"};
	this.rtwnameHashMap["<S1>/Product1"] = {sid: "zbiorniki_objekt:17"};
	this.sidHashMap["zbiorniki_objekt:17"] = {rtwname: "<S1>/Product1"};
	this.rtwnameHashMap["<S1>/Product2"] = {sid: "zbiorniki_objekt:22"};
	this.sidHashMap["zbiorniki_objekt:22"] = {rtwname: "<S1>/Product2"};
	this.rtwnameHashMap["<S1>/Product3"] = {sid: "zbiorniki_objekt:40"};
	this.sidHashMap["zbiorniki_objekt:40"] = {rtwname: "<S1>/Product3"};
	this.rtwnameHashMap["<S1>/Product4"] = {sid: "zbiorniki_objekt:41"};
	this.sidHashMap["zbiorniki_objekt:41"] = {rtwname: "<S1>/Product4"};
	this.rtwnameHashMap["<S1>/Sqrt"] = {sid: "zbiorniki_objekt:6"};
	this.sidHashMap["zbiorniki_objekt:6"] = {rtwname: "<S1>/Sqrt"};
	this.rtwnameHashMap["<S1>/Sqrt1"] = {sid: "zbiorniki_objekt:16"};
	this.sidHashMap["zbiorniki_objekt:16"] = {rtwname: "<S1>/Sqrt1"};
	this.rtwnameHashMap["<S1>/Sum"] = {sid: "zbiorniki_objekt:3"};
	this.sidHashMap["zbiorniki_objekt:3"] = {rtwname: "<S1>/Sum"};
	this.rtwnameHashMap["<S1>/Sum2"] = {sid: "zbiorniki_objekt:12"};
	this.sidHashMap["zbiorniki_objekt:12"] = {rtwname: "<S1>/Sum2"};
	this.rtwnameHashMap["<S1>/H1"] = {sid: "zbiorniki_objekt:30"};
	this.sidHashMap["zbiorniki_objekt:30"] = {rtwname: "<S1>/H1"};
	this.rtwnameHashMap["<S1>/H2"] = {sid: "zbiorniki_objekt:31"};
	this.sidHashMap["zbiorniki_objekt:31"] = {rtwname: "<S1>/H2"};
	this.rtwnameHashMap["<S1>/h1_real"] = {sid: "zbiorniki_objekt:38"};
	this.sidHashMap["zbiorniki_objekt:38"] = {rtwname: "<S1>/h1_real"};
	this.rtwnameHashMap["<S1>/h2_real"] = {sid: "zbiorniki_objekt:39"};
	this.sidHashMap["zbiorniki_objekt:39"] = {rtwname: "<S1>/h2_real"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
