q = 100;
c1 = 35;
c2 = 32;
a1 = 10;
a2 = 10;
p = 0;
v1 = 1;
v2 = 1;
H10 = 10;
H20 = 5;
sim("zbiorniki_objekt.slx")